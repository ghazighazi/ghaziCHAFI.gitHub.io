import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { ShopComponent } from './components/shop/shop.component';
import { BattleComponent } from './components/battle/battle.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { CardComponent } from './components/card/card.component';

import { BddService } from "./services/bdd.service";

import { PokeidPipe } from './pipes/pokeid.pipe';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ShopComponent,
    BattleComponent,
    NavbarComponent,
    PokeidPipe,
    CardComponent
  ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],

  providers: [ BddService ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
