import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Pokemon } from "../../interfaces/pokemon";

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  @Input() poke:Pokemon; // Raccourci pour le même nom
  @Input() type:boolean; 
  @Input() money:number; 
  @Output() select:EventEmitter<boolean> = new EventEmitter<boolean>();
  // @Input('poke') AutreNom; -> syntaxe complète

  constructor() { }

  possible(){
    return this.poke.prix <= this.money;
  }

  action(){
    this.select.emit();
  }

  ngOnInit() {
  }

}
