import { Component, OnInit } from '@angular/core';
import { BddService } from "../../services/bdd.service";

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  get money():number{
    return this.bdd.money;
  }

  get nom():number{
    return this.bdd.nom;
  }
  constructor(private bdd:BddService) { }

  ngOnInit() {
  }

}
