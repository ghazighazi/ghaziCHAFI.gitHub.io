import { Component, OnInit } from '@angular/core';
import { BddService } from "../../services/bdd.service";
import { Pokemon } from "../../interfaces/pokemon";

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})

export class ShopComponent implements OnInit {

  aff:boolean = false;
  rep:boolean = false;

  get pokemons():Array<Pokemon>{
    return this.bdd.pokemons;
  }

  get money():number{
    return this.bdd.money;
  }

  get equipe():Array<Pokemon>{
    return this.bdd.equipe;
  }
  pokeSelect:Pokemon|null = null;
  type:boolean = true;

  get currentPoke():Pokemon{
    if(this.pokeSelect)
      return this.pokeSelect;
    else
      return this.bdd.pokemons[0];
  }

  constructor(private bdd:BddService) {
    this.bdd.refresh();
   // Intitialisation
    
   }

  getPair(i:number){
    if(i%2 == 0)
      return "pair";
  }
  setOver(type:boolean, poke:Pokemon){
    this.type = type;
    this.pokeSelect = poke;
  }
  select(){
   if(this.type){
      this.rep = this.bdd.achat(this.currentPoke);
      this.aff = true;
      setTimeout(()=>{
        this.aff = false;
      }, 2000)
   }
    
   else
   this.bdd.vente(this.currentPoke.id);  
  }
  ngOnInit() {
  }

}

