export interface Pokemon {
    id:number;
    nom:string;
    num:number;
    type:string;
    vie:number;
    prix:number;
    atk:number;
    def:number;
    vit:number;
}
// {nom: "Tortank", num: 9, type: "Eau", vie: 110, atk:76, def: 82, vit: 76},