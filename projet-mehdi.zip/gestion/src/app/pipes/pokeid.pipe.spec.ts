import { PokeidPipe } from './pokeid.pipe';

describe('PokeidPipe', () => {
  it('create an instance', () => {
    const pipe = new PokeidPipe();
    expect(pipe).toBeTruthy();
  });
});
