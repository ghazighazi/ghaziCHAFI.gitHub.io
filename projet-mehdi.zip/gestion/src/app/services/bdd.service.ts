import { Injectable } from '@angular/core';
import { Pokemon } from "../interfaces/pokemon";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BddService {

  constructor(private http:HttpClient) { }

  private _pokemons:Array<Pokemon>;
  private _equipe:Array<Pokemon>;
  private _profil:any;

  get money():number{
    return this._profil.money;
  }

  get nom():number{
    return this._profil.name;
  }

  get pokemons():Array<Pokemon>{
    return this._pokemons;
  }
  get equipe():Array<Pokemon>{
    return this._equipe;
  }

  achat(p:Pokemon):boolean{
    let a:boolean = false;
    if(this.money > p.prix){
      a = true;
      p.id = null;
      let url = "http://localhost:3000/equipe";
      this.http.post(url, p).subscribe(
        (reponse)=>{
          console.log(reponse);
          let profilInterne = this._profil;
          profilInterne.money -= p.prix;
          url = "http://localhost:3000/profil";
          this.http.put(url, profilInterne).subscribe(
            (res)=>{
              console.log(res);
              this.refresh();
              
            }
          );
        }); 
    }
    return a;
  }

  vente(pId:number){
    let url = "http://localhost:3000/equipe/";
    this.http.delete(url+pId).subscribe(
      (reponse)=>{
        console.log(reponse);
        this.refresh();
      }
    );
    
  }

  refresh():void{
      let url:string = "http://localhost:3000/pokemons";
      this.http.get(url).subscribe((res)=>{
        this._pokemons = <Array<Pokemon>>res;
      });
      url = "http://localhost:3000/equipe";
      this.http.get(url).subscribe((res)=>{
        this._equipe = <Array<Pokemon>>res;
      });
      url = "http://localhost:3000/profil";
      this.http.get(url).subscribe((res)=>{
        this._profil = <any>res;
      });           
  }

}
